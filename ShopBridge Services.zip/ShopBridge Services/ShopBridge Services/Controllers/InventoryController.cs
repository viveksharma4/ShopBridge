﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShopBridge_Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ShopBridge_Services.Controllers
{

    [Route("[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly ShopBridgeContext _dbContext;
        private readonly ILogger<InventoryController> _logger;

        public InventoryController(ShopBridgeContext context, ILogger<InventoryController> logger)
        {
            _dbContext = context;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IEnumerable<Inventory>> Get()
        {
            List<Inventory> inventoryList = new List<Inventory>();
            try
            {
                inventoryList = await _dbContext.Inventories
                                 .Where(c => c.IsActive == true)
                                 .OrderBy(c => c.Name).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inventoryList;
        }

        [HttpGet("{id}")]
        public async Task<Inventory> Get(int id)
        {
            Inventory item = new Inventory();
            try
            {
                item = await _dbContext.Inventories
                                 .Where(c => c.Id == id && c.IsActive == true)
                                 .FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return item;
        }

        [HttpPost]
        public async Task<bool> Post([FromBody] dynamic inventory)
        {
            bool result = false;
            try
            {
                var data = JsonConvert.DeserializeObject(inventory.ToString());
                int id = Convert.ToInt16(data.Id.Value);
                Inventory dbRecord = await _dbContext.Inventories.Where(x => x.Id == id && x.IsActive == true).FirstOrDefaultAsync();
                if (dbRecord != null)
                {
                    dbRecord.Name = data.Name.Value;
                    dbRecord.Price = data.Price.Value;
                    dbRecord.Description = data.Description.Value;
                    dbRecord.UpdatedBy = "System";
                    dbRecord.UpdatedDate = DateTime.Now;
                    await _dbContext.SaveChangesAsync();
                    result = true;
                }
                else
                {
                    dbRecord = new Inventory();
                    dbRecord.Name = data.Name.Value;
                    dbRecord.Price = data.Price.Value;
                    dbRecord.Description = data.Description.Value;
                    dbRecord.CreatedBy = "System";
                    dbRecord.CreatedDate = DateTime.Now;
                    dbRecord.IsActive = true;
                    _dbContext.Inventories.Add(dbRecord);
                    await _dbContext.SaveChangesAsync();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        // DELETE api/<InventoryController>/5
        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            bool result = false;
            try
            {
                Inventory dbRecord = await _dbContext.Inventories.Where(x => x.Id == id && x.IsActive == true).FirstOrDefaultAsync();
                if (dbRecord != null)
                {
                    dbRecord.IsActive = false;
                    dbRecord.UpdatedBy = "System";
                    dbRecord.UpdatedDate = DateTime.Now;
                    await _dbContext.SaveChangesAsync();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
    }
}
