﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ShopBridge_Services.Models
{
    [Table("Inventory")]
    public partial class Inventory
    {
        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(150)]
        public string Name { get; set; }
        public double Price { get; set; }
        [StringLength(500)]
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        [Required]
        [Column("Created_By")]
        [StringLength(100)]
        public string CreatedBy { get; set; }
        [Column("Created_Date", TypeName = "datetime")]
        public DateTime CreatedDate { get; set; }
        [Column("Updated_By")]
        [StringLength(100)]
        public string UpdatedBy { get; set; }
        [Column("Updated_Date", TypeName = "datetime")]
        public DateTime? UpdatedDate { get; set; }
    }
}
