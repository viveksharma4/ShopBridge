using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using ShopBridge.Controllers;
using ShopBridge.Models;
using System.Threading;

namespace NUnitTest_ShopBridge
{
    [TestFixture]
    public class Tests
    {
        ILogger<HomeController> m_logger;
        HomeController m_controller;

        //[SetUp]
        //public void Setup(ILogger<HomeController> logger)
        //{
        //    m_logger = logger;
        //    m_controller = new HomeController(m_logger);
        //}
        public Tests()
        {
            //m_logger = logger;
            m_controller = new HomeController(m_logger);
        }

        [Test]
        public void Index_RunStatus()
        {
            var okResult = m_controller.Index();
            Thread.Sleep(2000);
            Assert.AreEqual("RanToCompletion", okResult.Status.ToString());
        }
        [Test]
        public void Index_ReturnsView()
        {
            var okResult = m_controller.Index();
            Thread.Sleep(2000);
            Assert.AreEqual(typeof(ViewResult), okResult.Result.GetType());
        }

        [Test]
        public void AddEdit_RunStatus()
        {
            int id = 1;
            var okResult = m_controller.AddEdit(id);
            Thread.Sleep(2000);
            Assert.AreEqual("RanToCompletion", okResult.Status.ToString());
        }

        [Test]
        public void AddEdit_ReturnsView()
        {
            int id = 1;
            var okResult = m_controller.AddEdit(id);
            Thread.Sleep(2000);
            Assert.AreEqual(typeof(ViewResult), okResult.Result.GetType());
        }

        [Test]
        public void Save_RunStatus()
        {
            Inventory inventory = new Inventory();
            inventory.Id = 1;
            inventory.Name = "Shirt";
            inventory.Price = 500;
            inventory.Description = "New Shirt";
            var okResult = m_controller.Save(inventory);
            Thread.Sleep(2000);
            Assert.AreEqual("RanToCompletion", okResult.Status.ToString());
        }

        [Test]
        public void Save_ReturnsView()
        {
            Inventory inventory = new Inventory();
            inventory.Id = 1;
            inventory.Name = "Shirt";
            inventory.Price = 500;
            inventory.Description = "New Shirt";
            var okResult = m_controller.Save(inventory);
            Thread.Sleep(2000);
            Assert.AreEqual(typeof(RedirectToActionResult), okResult.Result.GetType());
        }

        [Test]
        public void Delete_RunStatus()
        {
            int id = 1;
            var okResult = m_controller.Delete(id);
            Thread.Sleep(2000);
            Assert.AreEqual("RanToCompletion", okResult.Status.ToString());
        }

        [Test]
        public void Delete_ReturnsView()
        {
            int id = 1;
            var okResult = m_controller.Delete(id);
            Thread.Sleep(2000);
            Assert.AreEqual(typeof(RedirectToActionResult), okResult.Result.GetType());
        }

    }
}