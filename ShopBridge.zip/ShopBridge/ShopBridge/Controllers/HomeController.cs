﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace ShopBridge.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly string API_URL = "https://localhost:44312/";
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Inventory> inventoryModel = null;
            try
            {
                var httpCLientHandler = new HttpClientHandler();
                httpCLientHandler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
                using (var client = new HttpClient(httpCLientHandler))
                {
                    client.BaseAddress = new Uri(API_URL);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = await client.GetAsync("Inventory");
                    inventoryModel = JsonConvert.DeserializeObject<List<Inventory>>(response.Content.ReadAsStringAsync().Result);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message.ToString());
                return StatusCode(500, "Internal server error");
            }
            return View(inventoryModel);
        }

        public async Task<IActionResult> AddEdit(int id)
        {
            Inventory inventoryModel = null;
            if (ModelState.IsValid)
            {
                try
                { 
                if (id == 0)
                {
                    inventoryModel = new Inventory();
                }
                else
                {
                    var httpCLientHandler = new HttpClientHandler();
                    httpCLientHandler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
                    using (var client = new HttpClient(httpCLientHandler))
                    {
                        client.BaseAddress = new Uri(API_URL);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        var response = await client.GetAsync("Inventory/" + id);
                        inventoryModel = JsonConvert.DeserializeObject<Inventory>(response.Content.ReadAsStringAsync().Result);
                    }
                }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message.ToString());
                    return StatusCode(500, "Internal server error");
                }
            }

            return View(inventoryModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Save(Inventory inventory)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    bool isSaved = false;
                    var httpCLientHandler = new HttpClientHandler();
                    httpCLientHandler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
                    using (var client = new HttpClient(httpCLientHandler))
                    {
                        client.BaseAddress = new Uri(API_URL);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        var json = JsonConvert.SerializeObject(inventory);
                        var result = await client.PostAsJsonAsync("Inventory", json);
                        isSaved = JsonConvert.DeserializeObject<bool>(result.Content.ReadAsStringAsync().Result);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message.ToString());
                    return StatusCode(500, "Internal server error");
                }
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            bool isDeleted = false;
            try
            {
                var httpCLientHandler = new HttpClientHandler();
                httpCLientHandler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
                using (var client = new HttpClient(httpCLientHandler))
                {
                    client.BaseAddress = new Uri(API_URL);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = await client.DeleteAsync("Inventory/" + id);
                    isDeleted = JsonConvert.DeserializeObject<bool>(response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message.ToString());
                return StatusCode(500, "Internal server error");
            }

            return RedirectToAction("Index");
        }

        public static Func<HttpRequestMessage, X509Certificate2, X509Chain, SslPolicyErrors, bool> DangerousAcceptAnyServerCertificateValidator { get; } = delegate { return true; };
    }
}
