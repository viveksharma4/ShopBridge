﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ShopBridge.Models
{
    public class Inventory
    {
        public long Id { get; set; }
        [Required(ErrorMessage = "Please enter name of item")]
        [StringLength(150)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please provide price of item")]       
        public double? Price { get; set; }
        [StringLength(500)]
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
